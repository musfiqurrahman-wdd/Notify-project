----------------------------------------------------------------------------------------------------------
This resource has been created by Michael Reimer from www.bestpsdfreebies.com\
----------------------------------------------------------------------------------------------------------

TERMS OF USE:

This resource is free for use in both personal and commercial projects.

Please ask for special uses. No attribution or backlinks are required (though wonderfully appreciated), but any form of spreading the word is always fantastic!

You are not permitted to make this resources available for distribution elsewhere, as is, without prior consent. If you want to have a little article and have it link back to my site, that'd be awesome!


Cheers,

Michael Reimer | Best PSD Freebies

_________________________
website: www.bestpsdfreebies.com
email: info@bestpsdfreebies.com